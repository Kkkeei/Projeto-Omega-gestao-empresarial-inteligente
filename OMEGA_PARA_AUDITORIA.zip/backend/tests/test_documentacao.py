from pathlib import Path
from uuid import uuid4

from app.modules.documentacao import service


def _empresa_id() -> int:
    conexao = service.conectar_banco()
    try:
        row = conexao.execute("SELECT id FROM empresas ORDER BY id LIMIT 1").fetchone()
        assert row is not None
        return int(row["id"])
    finally:
        conexao.close()


def test_documentacao_subpastas_criacao_navegacao_e_arquivo_fisico():
    empresa_id = _empresa_id()
    suffix = uuid4().hex[:8]
    root = service.criar_categoria(empresa_id, f"__TESTE_RAIZ_{suffix}", "Pasta de teste")
    child = service.criar_categoria(empresa_id, f"__TESTE_SUBPASTA_{suffix}", "Subpasta de teste", root["id"])
    grandchild = service.criar_categoria(empresa_id, f"__TESTE_NIVEL_3_{suffix}", "Subpasta de terceiro nível", child["id"])
    try:
        assert child["categoria_pai_id"] == root["id"]
        assert grandchild["categoria_pai_id"] == child["id"]

        categorias = service.listar_categorias(empresa_id)
        by_id = {item["id"]: item for item in categorias}
        assert root["id"] in by_id
        assert child["id"] in by_id
        assert by_id[root["id"]]["subpastas_count"] >= 1
        assert by_id[child["id"]]["categoria_pai_id"] == root["id"]
        assert by_id[grandchild["id"]]["categoria_pai_id"] == child["id"]

        root_dir = service.STORAGE_ROOT / str(empresa_id) / str(root["id"])
        child_dir = service.STORAGE_ROOT / str(empresa_id) / str(child["id"])
        grandchild_dir = service.STORAGE_ROOT / str(empresa_id) / str(grandchild["id"])
        assert root_dir.is_dir()
        assert child_dir.is_dir()
        assert grandchild_dir.is_dir()

        renamed = service.atualizar_categoria(child["id"], f"__TESTE_SUBPASTA_RENOMEADA_{suffix}", "Atualizada")
        assert renamed["nome"].endswith(suffix)

        archived = service.arquivar_categoria(root["id"])
        assert archived["categorias_arquivadas"] >= 3
        remaining = service.listar_categorias(empresa_id)
        remaining_ids = {item["id"] for item in remaining}
        assert root["id"] not in remaining_ids
        assert child["id"] not in remaining_ids
        assert grandchild["id"] not in remaining_ids
    finally:
        # Diretórios vazios são seguros para remover; documentos reais não são tocados.
        for path in [service.STORAGE_ROOT / str(empresa_id) / str(grandchild["id"]), service.STORAGE_ROOT / str(empresa_id) / str(child["id"]), service.STORAGE_ROOT / str(empresa_id) / str(root["id"] )]:
            try:
                path.rmdir()
            except OSError:
                pass
