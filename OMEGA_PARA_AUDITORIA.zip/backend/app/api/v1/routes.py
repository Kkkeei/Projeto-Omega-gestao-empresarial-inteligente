from fastapi import APIRouter, Depends

from app.api.v1.auth.routes import current_user
from app.api.v1.certidoes.routes import router as certidoes_router
from app.api.v1.dashboard.routes import router as dashboard_router
from app.api.v1.empresas.routes import router as empresas_router
from app.api.v1.pendencias.routes import router as pendencias_router
from app.modules.documentacao.routes import router as documentacao_router
from app.modules.faturamento.routes import router as faturamento_router
from app.modules.impostos.routes import router as impostos_router
from app.api.v1.automacoes.routes import router as automacoes_router
from app.modules.certificados.routes import router as certificados_digitais_router

router = APIRouter(dependencies=[Depends(current_user)])
router.include_router(empresas_router)
router.include_router(certidoes_router)
router.include_router(pendencias_router)
router.include_router(dashboard_router)
router.include_router(documentacao_router)
router.include_router(faturamento_router)
router.include_router(impostos_router)
router.include_router(automacoes_router)
router.include_router(certificados_digitais_router)
