import { useEffect, useState } from 'react';
import { NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard, Building2, FileCheck2, AlertTriangle, ChevronRight, LogOut,
  Users, ShieldCheck, Folder, BadgeDollarSign, ReceiptText, KeyRound, Search,
  Keyboard, X, ArrowRight,
} from 'lucide-react';
import { useAuth } from '../../auth/AuthContext';

const links = [
  ['/', 'Dashboard', LayoutDashboard],
  ['/empresas', 'Empresas', Building2],
  ['/certidoes', 'Certidões', FileCheck2],
  ['/certificados', 'Certificados', KeyRound],
  ['/documentacao', 'Documentação', Folder],
  ['/pendencias', 'Pendências', AlertTriangle],
  ['/faturamento', 'Faturamento', BadgeDollarSign],
  ['/impostos', 'Impostos', ReceiptText],
] as const;

type ShortcutItem = { keys: string; action: string };
const shortcuts: ShortcutItem[] = [
  { keys: 'Ctrl + K', action: 'Abrir navegação rápida' },
  { keys: '?', action: 'Mostrar atalhos de teclado' },
  { keys: 'Alt + 1 … 8', action: 'Abrir módulo pela posição no menu' },
  { keys: 'Esc', action: 'Fechar janela ou menu aberto' },
];
const documentShortcuts: ShortcutItem[] = [
  { keys: 'Alt + Shift + F', action: 'Pesquisar na pasta atual' },
  { keys: 'Alt + Shift + N', action: 'Criar subpasta na pasta atual' },
  { keys: 'Alt + Shift + U', action: 'Enviar documento para a pasta atual' },
  { keys: 'Alt + ↑', action: 'Subir para a pasta pai' },
];

export function Layout() {
  const loc = useLocation();
  const navigate = useNavigate();
  const { usuario, logout } = useAuth();
  const [paletteOpen, setPaletteOpen] = useState(false);
  const [helpOpen, setHelpOpen] = useState(false);
  const [query, setQuery] = useState('');
  const title = links.find((x) => x[0] === loc.pathname)?.[1]
    || (loc.pathname === '/usuarios' ? 'Usuários'
      : loc.pathname === '/alterar-senha' ? 'Alterar senha'
        : loc.pathname.startsWith('/documentacao/') ? 'Documentação'
          : loc.pathname.startsWith('/faturamento/') ? 'Faturamento'
            : loc.pathname.startsWith('/impostos/') ? 'Impostos' : 'ÔMEGA');
  const visibleLinks = links.filter(([, label,]) => label.toLocaleLowerCase('pt-BR').includes(query.trim().toLocaleLowerCase('pt-BR')));

  useEffect(() => {
    function onKeyDown(event: KeyboardEvent) {
      const target = event.target as HTMLElement | null;
      const editing = !!target && (target.isContentEditable || ['INPUT', 'TEXTAREA', 'SELECT'].includes(target.tagName));
      if (event.key === 'Escape') {
        setPaletteOpen(false);
        setHelpOpen(false);
        return;
      }
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') {
        event.preventDefault();
        setQuery('');
        setHelpOpen(false);
        setPaletteOpen(true);
        return;
      }
      if (!editing && event.key === '?' && !event.ctrlKey && !event.metaKey && !event.altKey) {
        event.preventDefault();
        setPaletteOpen(false);
        setHelpOpen((value) => !value);
        return;
      }
      if (!editing && event.altKey && !event.ctrlKey && !event.metaKey && /^[1-8]$/.test(event.key)) {
        event.preventDefault();
        const item = links[Number(event.key) - 1];
        if (item) navigate(item[0]);
      }
    }
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [navigate]);

  useEffect(() => {
    setPaletteOpen(false);
    setHelpOpen(false);
  }, [loc.pathname]);

  function go(to: string) {
    navigate(to);
    setPaletteOpen(false);
    setQuery('');
  }

  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand"><div className="brand-mark">Ω</div><div><strong>ÔMEGA</strong><span>GESTÃO EMPRESARIAL</span></div></div>
      <nav className="nav" aria-label="Navegação principal">
        {links.map(([to, label, Icon], index) => <NavLink key={to} to={to} end={to === '/'} className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
          <Icon size={17}/><span>{label}</span><kbd className="nav-shortcut">Alt+{index + 1}</kbd><ChevronRight size={14} className="nav-arrow"/>
        </NavLink>)}
        {usuario?.perfil === 'ADMIN' && <NavLink to="/usuarios" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}><Users size={17}/><span>Usuários</span><ChevronRight size={14} className="nav-arrow"/></NavLink>}
      </nav>
      <button className="sidebar-command" type="button" onClick={() => { setQuery(''); setPaletteOpen(true); }}><Search size={15}/><span>Ir para...</span><kbd>Ctrl K</kbd></button>
      <div className="sidebar-user"><span className="user-avatar">{(usuario?.nome || 'U').slice(0, 1).toUpperCase()}</span><div><strong>{usuario?.nome}</strong><small>{usuario?.perfil === 'ADMIN' ? 'Administrador' : 'Usuário'}</small></div><button className="icon-button dark" title="Sair" onClick={() => void logout()}><LogOut size={15}/></button></div>
      <div className="sidebar-note"><span>Dossiê empresarial</span><strong>Histórico permanente</strong><small>A situação atual é importante. O histórico nunca é perdido.</small></div>
    </aside>
    <main className="main-content">
      <header className="topbar"><div><span className="eyebrow">PLATAFORMA ÔMEGA</span><h1>{title}</h1></div><div className="topbar-user"><button className="topbar-shortcut" type="button" onClick={() => { setQuery(''); setPaletteOpen(true); }}><Search size={15}/><span>Buscar módulo</span><kbd>Ctrl K</kbd></button><button className="topbar-help" type="button" title="Atalhos de teclado (?)" onClick={() => setHelpOpen(true)}><Keyboard size={16}/></button><span className="top-user-badge"><ShieldCheck size={13}/> Sessão segura</span><div className="top-user-info"><strong>{usuario?.nome}</strong><span>{usuario?.email}</span></div><button className="icon-button" onClick={() => void logout()} title="Sair"><LogOut size={15}/></button></div></header>
      <Outlet/>
    </main>

    {paletteOpen && <div className="omega-overlay" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setPaletteOpen(false); }}>
      <section className="omega-command-palette" role="dialog" aria-modal="true" aria-label="Navegação rápida">
        <div className="omega-palette-search"><Search size={19}/><input autoFocus value={query} onChange={(event) => setQuery(event.target.value)} onKeyDown={(event) => { if (event.key === 'Enter' && visibleLinks[0]) go(visibleLinks[0][0]); }} placeholder="Para onde você quer ir?" aria-label="Pesquisar módulos"/><kbd>Esc</kbd><button className="icon-button" onClick={() => setPaletteOpen(false)} title="Fechar"><X size={15}/></button></div>
        <div className="omega-palette-caption">MÓDULOS</div>
        <div className="omega-palette-results">{visibleLinks.map(([to, label, Icon], index) => <button type="button" className="omega-palette-item" key={to} onClick={() => go(to)}><span className="omega-palette-icon"><Icon size={17}/></span><span>{label}</span><kbd>Alt+{links.findIndex((item) => item[0] === to) + 1}</kbd><ArrowRight size={15}/></button>)}{usuario?.perfil === 'ADMIN' && 'usuários'.includes(query.trim().toLowerCase()) && <button type="button" className="omega-palette-item" onClick={() => go('/usuarios')}><span className="omega-palette-icon"><Users size={17}/></span><span>Usuários</span><ArrowRight size={15}/></button>}{visibleLinks.length === 0 && !(usuario?.perfil === 'ADMIN' && 'usuários'.includes(query.trim().toLowerCase())) && <div className="omega-palette-empty">Nenhum módulo corresponde a “{query}”.</div>}</div>
        <footer className="omega-palette-footer"><span><kbd>↵</kbd> Abrir módulo</span><span><kbd>Esc</kbd> Fechar</span><button type="button" onClick={() => { setPaletteOpen(false); setHelpOpen(true); }}><Keyboard size={13}/> Atalhos</button></footer>
      </section>
    </div>}

    {helpOpen && <div className="omega-overlay" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setHelpOpen(false); }}><section className="omega-shortcuts-dialog" role="dialog" aria-modal="true" aria-label="Atalhos de teclado"><header><div><span className="eyebrow">PRODUTIVIDADE</span><h2>Atalhos de teclado</h2></div><button className="icon-button" onClick={() => setHelpOpen(false)} title="Fechar"><X size={15}/></button></header><p>Use o ÔMEGA sem precisar navegar por todos os menus.</p>{[...shortcuts, ...(loc.pathname.startsWith('/documentacao/empresa/') ? documentShortcuts : [])].map((shortcut) => <div className="omega-shortcut-row" key={shortcut.keys}><span>{shortcut.action}</span><kbd>{shortcut.keys}</kbd></div>)}<div className="omega-shortcut-note">Os atalhos de navegação respeitam os campos de texto: enquanto você digita, eles não interceptam suas teclas.</div><footer><button className="button primary" onClick={() => setHelpOpen(false)}>Entendi</button></footer></section></div>}
  </div>;
}
